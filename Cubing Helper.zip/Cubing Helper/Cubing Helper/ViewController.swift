//
//  ViewController.swift
//  Cubing Helper
//
//  Created by Mehul Chaudhari on 3/25/20.
//  Copyright © 2020 Mehul Chaudhari. All rights reserved.
//

import UIKit
import WebKit

class HomeViewController: UIViewController {

    @IBAction func TimerButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "TimerSegue", sender: self)
    }
    
    
    @IBAction func TwoButtonPressed(_ sender: Any) {
       
        performSegue(withIdentifier: "2x2segue", sender: self)
    }
    
    
    @IBAction func ThreeButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "3x3segue", sender: self)
    }
    
   
        
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class TwoViewController: UIViewController {
    
    
    @IBAction func OrtegaButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Ortegasegue", sender: self)
    }
    
    @IBAction func CLL(_ sender: Any) {
        
        performSegue(withIdentifier: "CLLsegue", sender: self)
    }
    
    @IBAction func EGoneButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "EG1segue", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class ThreeViewController: UIViewController {

    
    @IBAction func OLLbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "OLLsegue", sender: self)
    }
    
    
    @IBAction func PLLbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "PLLsegue", sender: self)
    }
    
    @IBAction func COLLbuttonPressed(_ sender: Any) {
        
        
        
        performSegue(withIdentifier: "COLLsegue", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class OrtegaViewController: UIViewController {
    
    @IBAction func OrtegaOLLbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "OrtegaOLLsegue", sender: self)
    }
    
    @IBAction func OrtegaPBLbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "OrtegaPBLsegue", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class CLLViewController: UIViewController {

    @IBAction func SuneCLLbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "SuneCLLsegue", sender: self)
    }
    
    @IBAction func AntisuneCLLbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "AntisuneCLLsegue", sender: self)
    }
    
    @IBAction func PiCLLbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "PiCLLsegue", sender: self)
    }
    
    @IBAction func UCLLbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "UCLLsegue", sender: self)
    }
    
    @IBAction func LCLLbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "LCLLsegue", sender: self)
    }
    
    @IBAction func TCLLbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "TCLLsegue", sender: self)
    }
    
    @IBAction func HCLLbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "HCLLsegue", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class EGoneViewController: UIViewController {

    @IBAction func SuneEGbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "SuneEGsegue", sender: self)
    }
    
    @IBAction func AntisuneEGbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "AntisuneEGsegue", sender: self)
    }
    
    @IBAction func PiEGbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "PiEGsegue", sender: self)
    }
    
    @IBAction func UEGbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "UEGsegue", sender: self)
    }
    
    @IBAction func LEGbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "LEGsegue", sender: self)
    }
    
    @IBAction func TEGbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "TEGsegue", sender: self)
    }
    
    @IBAction func HEGbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "HEGsegue", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class OLLViewController: UIViewController {

    @IBAction func CrossButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Crosssegue", sender: self)
    }
    
    
    @IBAction func DotButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Dotsegue", sender: self)
    }
    
    
    @IBAction func PshapeButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Pshapesegue", sender: self)
    }
    
    
    @IBAction func WshapeButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Wshapesegue", sender: self)
    }
    
    @IBAction func LshapeButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Lshapesegue", sender: self)
    }
    
    @IBAction func CshapeButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Cshapesegue", sender: self)
    }
    
    @IBAction func TshapeButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Tshapesegue", sender: self)
    }
    
    @IBAction func IshapeButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Ishapesegue", sender: self)
    }
    
    @IBAction func SquareButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Squaresegue", sender: self)
    }
    
    @IBAction func BLBbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "BLBsegue", sender: self)
    }
    
    @IBAction func SLBbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "SLBsegue", sender: self)
    }
    
    @IBAction func FishButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Fishsegue", sender: self)
    }
    
    @IBAction func KnightButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Knightsegue", sender: self)
    }
    
    @IBAction func AwkwardButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Awkwardsegue", sender: self)
    }
    
    @IBAction func ACOButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "ACOsegue", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class PLLViewController: UIViewController {
    
    
    @IBAction func EPLLbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "EPLLsegue", sender: self)
    }
    
    
    @IBAction func OESbuttonPressed(_ sender: Any) {
        
        
        performSegue(withIdentifier: "OESsegue", sender: self)
    }

    @IBAction func AESbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "AESsegue", sender: self)
    }
    
    
    @IBAction func DCSbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "DCSsegue", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class EPLLViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class OESViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class AESViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class DCSViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class CrossViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class DotViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class PshapeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class WshapeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class LshapeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class CshapeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class IshapeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class SqaureshapeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class BLBshapeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class SLBshapeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class FishViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class KnightViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class AwkwardViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class ACOViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class COLLViewController: UIViewController {
    
    @IBAction func SuneButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Sunesegue", sender: self)
    }
    
    @IBAction func AntisuneButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Antisunesegue", sender: self)
    }
    
    @IBAction func TbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Tsegue", sender: self)
    }
    
    @IBAction func UbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Usegue", sender: self)
    }
    
    @IBAction func LbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Lsegue", sender: self)
    }
    
    @IBAction func PiButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Pisegue", sender: self)
    }
    
    @IBAction func HbuttonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Hsegue", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class SuneViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class AntisuneViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class TViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class UViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class LViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class PiViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class HViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class OrtegaOLLViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class OrtegaPBLViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class SuneCLLViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class AntisuneCLLViewController: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class PiCLLViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class UCLLViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class LCLLViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class TCLLViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class HCLLViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}



class SuneEGViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class AntisuneEGViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class PiEGViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class UEGViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class LEGViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class TEGViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class HEGViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

class TimerViewController: UIViewController {
   
    @IBOutlet var CompleteView: UIView!
    
    @IBOutlet weak var TimeLabel: UILabel!
    @IBOutlet weak var Scramble: UILabel!
    
    
    let ThreescrambleArray = ["R D R2 U L2 U2 B2 U' L2 F2 U' B2 L U F2 L' B D2 U' R2", "U D R2 U2 B R' L D F' U D2 R2 U2 F' U2 L2 F' U2 F2 L2 F'", "L2 R2 U L2 F2 U' B2 F2 L2 B2 F2 D' B' L' U R' B D2 U' F R'", "L2 B' U' F2 U2 F2 D R2 B2 L2 B2 U2 L2 F L R U' F L R'", "R' L F L' D' L' F2 L2 B' R' F2 R D2 B2 D2 R2 B2 R U2 R' D2", "L F2 R U2 B2 D2 B2 U2 L F2 R' F' U' R2 B U' R U' R2", "D2 R L' F R' L2 D F B R2 B2 U' R2 U' F2 U D2 L2 D F2", "F2 D B2 U L2 D B2 U2 B2 R2 D L R' B' U' L2 F U2 B D F'", "B' L2 F' D B2 L F' B R U F2 U2 F2 U' F2 D' F2 R2 U2 R2 D2", "R2 U2 L2 F D2 F' U2 B2 U2 F' R2 B' R' B U' F L2 U' L' D' L", "D2 L F B2 U' F2 U' L2 D2 F2 U F2 U2 B2 L' R F2 U' L' D' L2", "L D U2 F2 L B2 L2 F2 L' D2 L B2 L F' R' F' D' B L B", "R' U' L2 B2 U' L' F D L B2 R' U2 L' D2 F2 R U2 D2 L U2 F", "D2 B2 D2 L2 B2 F D2 F' U2 D' R' B' F' L F R D' R' U", "L2 B D2 R2 F L2 F' R2 F2 U2 L2 F' U' F D2 F' D B' R' U L", "U2 L2 U2 R2 U2 B2 D' B2 U F2 L B' R' F2 D' B2 L F L", "D2 F B2 U' B2 R2 D2 F2 L2 D L2 F2 R2 F' L2 D B' U' R' U2 R2", "L' U2 L2 F2 R2 F' R2 U2 F' D2 R2 B D' F2 L F2 U B2 F2", "F D2 L2 D2 U' L2 B2 U F2 R2 B' L' D2 L' R D' U2 L'", "D2 L2 U' R D2 B2 L2 D' B L2 F U2 D2 F D2 R2 F' R2 U2 D'", "R U' F2 L B2 R F2 U2 F2 U2 F2 L' B2 L' F R2 U B D' L' R", "F' D2 F D F2 D2 F' B2 U B2 L' B2 U2 B2 R' D2 R2 D2 R U2", "F' R U2 F2 D' L2 R2 D' L2 R2 F2 U R2 F L R U2 B F2 R2 B", "F2 U D2 R D2 B' D U2 F R2 F R2 U2 D2 F2 L2 F B2 R' F", "F2 L' D' L2 D2 U L2 B2 L2 R2 F2 D' F' R2 D B L D' L2", "B' D2 F' D2 F U2 R2 F2 U2 L2 U2 B' U B' D2 U' F' D' B R'", "D2 B2 D' L2 U' B2 D L2 D2 R2 U2 L' U2 F U R2 D' B U2 L F2", "U' R U2 F' R2 U L' F L' F R2 D2 B2 L2 U2 B' R2 F' L2 D2", "B2 L F B' D' R2 F R' U F2 R2 D2 F2 L2 D2 R' D2 L' F2 L", "D2 B' U2 B U2 B' D2 B2 U2 L2 D2 F L' D B' R2 D B' U2 R'", "R' B2 R2 B D2 B U2 F D2 B R2 B' R' U' B' R' D L' F' U F'", "D' F' U2 B2 R B2 R2 B2 R' U2 L' D2 U2 F R2 F2 D' U2 F2 U2", "D2 B2 U F R' F2 U F L2 B2 R2 F2 U' F2 L2 U B2 D B2 U' R", "F' L' U L2 D F2 L2 U B2 U' B2 L2 R2 U2 F' L' U' F2 U' B2 F'", "B2 R' U' B' L2 U B U' F' R' B2 L B2 D2 B2 R' F2 U2 R'", "L2 B2 U B2 R2 D U2 F2 D' L2 D F2 B D U2 L2 B R' B' F R", "D2 B2 F2 D' L2 D R2 B2 D' U' F R B U B' L' B F U F", "R' F' B2 D' B2 U L2 U B2 R2 B2 R2 U' L' D' R2 B F2 L R U", "B' U2 F2 L2 D2 F R2 F' L2 R2 B R D F U' L U2 R' F2 L' R2", "F2 D B2 D F2 L2 U B2 R2 U' L' U' R F' R' D' R U2 F U'", "L B2 U2 R2 U' B2 L2 U2 L2 D2 F' U R' B2 L F2 U' F' D'", "D2 R B L U2 D2 F U' R2 D2 R' F2 L U2 R D2 B2 R B2 U2", "U' L' U2 R' D2 R2 F2 D2 R D2 B2 R U F2 L2 B R' D2 F2 U", "R' U F' L2 B' D2 F2 U2 L2 F L2 D2 B L' D' U B2 D L D2", "D' U2 R2 B2 D2 R2 B2 R D2 R U2 B2 U F' R B' L' U L B'", "F' U L2 F2 L2 D B2 F2 L2 F2 D' F2 B' U' L B D2 F2 L' D B", "B D L U' L' F R U' L U B2 R2 D' R2 L2 B2 D2 R2 D L2 U'", "U F' U' D' R2 B2 D R L2 D' B2 U2 F2 D B2 R2 U' F2 B2 D2 F'", "R B2 L' U2 L2 U2 R U2 R B2 R' B2 D F D' F2 U' L' R' U' L2", "R2 D L2 D R2 B2 U B2 F2 D' U' B2 R' D' R' U L F' D R2 B'", "D' R2 U' B' L' B U' F L D2 B2 R2 U2 B2 L U2 D2 R2 F2 R' B'", "D B2 F2 R2 U F2 L2 U F2 L2 U B L' B2 F' R' B F U F'", "R' U2 B L2 R2 B L2 D2 F' L2 R2 D2 F' D' R U L R U' F U'", "U' R B2 U F2 R2 U2 F2 D L2 U' F2 U L2 B' D L' D B2 R2 D'", "L B' L U L U2 F U D2 R F2 B2 D2 R L2 U2 L' D2 F2", "F2 U L2 D F2 U B2 U L2 R F' D' B2 L B2 R2 U' F' D2", "B' U F2 U2 F2 U' L2 U' B2 L2 B2 L2 U' B U L' B2 D L F' L'", "B' F2 R D2 F2 L2 D2 L2 R' U2 F2 D2 F' L2 R U' L' D L' B2", "R2 U2 R2 B2 D2 R2 D F2 D2 L2 U F' U2 B' L D' R2 D B U2 F", "B2 D F2 D2 U' L2 B2 R2 U' L2 D B' R D U2 L2 U B L F2", "R2 D B R F2 B2 R F' R2 U2 D2 B L2 U2 F D2 B2 R2 L D2", "L2 F2 D R2 D L2 B2 U2 R2 U2 R2 B L B' L2 D' B' R D' B2", "L U' L B U2 D L U' R2 F U2 R2 U2 F' B R2 F' U2 R2 L", "D' F L2 F U' L B U2 L' D2 L2 U2 B2 U2 F2 R' B2 D2 R U' F", "B2 R2 B2 F' R2 B R2 F' L' D' L' D L2 R' F' D' B' U", "U2 F L2 B' R2 L2 D R U2 R F2 U2 L2 B2 D2 F2 D2 L F U'", "U L F2 R2 L' B' D' L' D' R2 U B2 D' B2 L2 B2 R2 U F2 U2", "D2 F2 L' U2 B2 R' D2 L' U2 L D2 R' U' R U R B R U2 B' F2", "F' D' R2 B2 D' L2 B L U' R2 D L2 U2 F2 U' L2 U2 F2 L2 B'", "F2 L' D2 U2 L' D2 L B2 L F2 U2 B2 F' R D U2 F U L B' F2", "L' D R F2 D2 L2 D2 L U2 B2 F2 R' F2 D2 F R' B D' R' D U2", "F2 L2 U2 R2 D2 R2 F L2 D2 B' L' D U' R' B U' L R2 B2 U2", "L R2 D F2 D F2 R2 D' F2 D2 B2 D2 B' U F' L B2 L2 U' B L2", "L2 B2 U2 B D2 F U2 F' L2 F L B' D' L2 U2 B U' L' U2 B", "U2 L2 D2 L' D2 L F2 L' D2 B L U B2 L2 D L' D'", "F2 R2 B2 R2 F2 D' L2 R2 D F2 D2 R D' B D B F R' D2 L'", "R2 B2 D2 F2 U2 L2 F2 R F2 L' D2 F2 B D' U2 R U B' F' L'", "R2 B' U' R2 L2 B2 D R F U2 B2 L2 B D2 B' L2 D2 B' L2 D2", "F' D' B D2 B' F2 U2 R2 F' U2 R2 U2 B R' U R2 B' U L F2", "D B2 F2 R2 B2 D2 U' B2 D' U' L' B D2 F' D F2 U L' F' U2", "U R' L2 U2 F2 U' B2 L2 U F2 U' B2 F2 R' D R2 U B L' B'L' U2 R D2 F2 R2 D2 L F2 R' U2 D' L' B D' B2 F D L' R2", "L2 D R2 B2 U' F2 U L2 D L2 D2 R U2 B' F L U2 B D R2 B2", "D2 F R2 F' D2 F2 D2 U2 B' D2 B' U' F' D L' B' R2 U2 R' F U'", "R' B' U' L2 F' D2 L2 F R2 U2 F' R2 F D R' F L' U' B R", "F2 B R B D2 B' D B2 R U2 F2 R2 L D2 R U' D2", "B' R2 F2 D2 F' R2 F U2 F2 L2 U' B F' U' B2 D' L D2 B'", "B2 R2 D2 L D2 U2 B2 R B2 L R2 B L D2 L' D' F L' R' F", "D2 R2 F2 D2 R' B2 L' U2 F2 R' D2 B F L D F' R' F' U F'", "B2 L U B2 R F D B2 L' F2 U' B2 D' R2 U2 B2 D B2 L2", "U2 F2 L2 B2 R2 U F2 U B2 D' U2 R' D' L' F D R2 F U' L U", "L' U R2 U' B2 F2 D' B2 D R2 D L2 D' R B F D L R D' U'", "R D2 B2 L2 U2 B R2 B' R2 D2 B' L2 F U' R' F2 D' R' B D2 R'", "B' D L2 D2 R' D2 F2 L' B2 F2 D2 B2 L F U2 R F' R2 U' B D'", "U D2 B D F U L2 D R L U2 D2 R' D2 L U2 R2 D2 B2 R2", "U2 D' F L' F2 D' R B2 L' F B U2 L2 F D2 R2 D2 F' B'", "F2 D2 R2 U2 R2 B2 D2 F' L2 R' F U' B' L B2 D F2 D2 L'", "U D' R D' B D L' B L' U' F2 B2 U' R2 F2 D' L2 F2 U2", "U' L2 B' U2 R2 D2 B' D2 B2 L2 F R2 B' L' B' D' L' F' L B D", "R F' D2 L' F2 D' L R2 F2 U B2 U L2 F2 B2 U' B2 L2 D2 B' L2", "B2 R2 U2 R2 B' R2 U2 B' F' R2 B R2 L' B' R U L D' F2 D F", "F U2 R2 U' F2 L2 U2 B2 U L2 R2 U2 B2 L' F U' B L' F2 R", "F2 R2 D2 L' D2 L' D2 L2 F2 D2 U' B F2 L' U L' F2 R F2", "R2 F L2 D L2 B2 R2 F2 D2 L2 D R2 U F U' F L B2 R B2", "D F L' D2 L' D' R U R2 F U2 B U2 D2 F2 L2 F L2 D", "B' D F2 B' L2 F R2 D' R F2 B2 U2 R' B2 U2 F2 R' F2 L' B'", "B2 D U2 L' D2 R' F2 R D2 U2 L' F2 U B R' U' B D2 L2", "D2 F L' D2 R' L2 F D F2 B' D2 F2 U2 R2 B' U2 B2 U2 R'", "L2 D2 U2 F D2 F' D2 F2 D2 L2 D2 B' L' F L U' B L' B2 L B", "D2 B2 U2 B2 R U2 L' D2 L' B2 D2 R' U F' R' F' R2 B F L' F2", "U2 B2 L2 F2 R2 D R2 B2 U' F2 R2 F R' U' L' U2 F' R B2 L' U'", "D' R' F B2 L U2 F' U D B2 U' B2 U2 B2 L2 U2 L2 D B' R'", "F' B' D' B2 R' F2 L' D U2 F' R2 F R2 F2 R2 L2 D2 F' L2 R", "B2 L' D2 L B' D R U' D2 F2 L2 B L2 D2 R2 B2 D2 B R2 B", "B2 L R2 U2 F' R2 F2 R2 B2 U2 F R2 U B2 F' L F2 L'", "U D2 L2 D2 R' D2 L' B2 L2 U2 D L' R' F D' U' R B'", "U' D L' F B2 U R B R U2 R2 F' L2 F U2 B' L2 B' R2 F L2", "B L' U2 L2 D L2 F2 D' R2 F2 U' F2 L2 U' B F2 D2 U L R2 B2", "B D' R' L2 B' U2 R B' U R2 F2 U2 L2 F2 R U2 D2 L' F2 L", "U B2 R' U2 D2 B2 R U' B D2 B2 L U2 R D2 R' B2 R' B2 R' B2", "U L2 B L2 F2 U2 R2 U2 B' D2 L2 R2 U' L' F' L' R' B' D' R", "U2 B2 L2 D2 U B2 U R2 D' U' R' F R2 B D F' L R2 D2 F", "L2 B2 U R D2 F2 D' F2 R2 B D2 R2 F' R2 B' U2 L2 F2", "L' F2 D2 B2 L2 U2 F2 L2 R2 U2 R' D B' U R2 F' D' R' F2 L' U", "F D' B' U' B' L2 U2 L F' R U2 F2 U2 L' B2 D2 R'", "U2 R U2 L' U2 B2 F2 R B2 U2 R' U' R D' U2 R' F L' D", "B L' F2 L2 R2 D' B2 F2 L2 D2 U B2 D F U2 B2 D' F D' R'", "D2 R' F2 D2 U2 R U2 L2 U2 F2 D2 F D L' U B2 L B' U2 F2", "B' L' D L U' F2 R2 B L' F2 D2 F' R2 D2 L2 B' L2 F L2 B'", "L' B' L2 B U2 R2 D2 R2 F' D2 B' R U' F' L B L U' B2", "B2 R2 F' L' B R2 U' L' D2 R2 F2 B2 R2 F' R2 D2 F' R2 F2", "B L B' D2 B L2 B' R2 F2 L2 D2 B' R2 F' R D' B' R U' F' R2", "F R2 D2 B' U2 B' R2 D2 F2 L2 B' U L B2 R D2 L D' R U2", "B2 D2 L' F2 U2 F2 R2 U2 R D' B' F' U F' R' B2 L U B'", "U2 L2 R2 U F2 L2 D B2 U B2 L' F' D2 U2 L' B D' B2 L'", "L2 B U2 R2 U2 R F2 R' D2 F2 R2 U2 B2 R U' B R U2 L' R' U2", "U' F2 U B2 D2 B2 D' B2 F2 D' R2 U B D L U' R2 U' B' F D'", "R' B2 D L2 U' L2 U R2 B2 R2 B2 D2 L2 R' D' F L2 F2 L U2", "F2 R D B2 L2 R2 D2 F U2 R2 F' D2 R2 U2 L U R' F2 U2 B U'", "D' R2 D2 B U2 L2 U2 F' R2 B D2 F R2 D' F L' R' U L U2 L'", "R2 U2 L2 F2 L2 U2 F2 R2 D' R2 B2 D F D U' L B U' R' U' F'", "R' L D F L' B' R' B U' L2 U F2 L2 U2 L2 D F2 U B2 U' L", "B' L2 U L' D B' U' F L2 D2 R' B2 L D2 R' B2 L' D2 B2 L D", "B2 R F' U2 F2 D' L R2 U B2 R2 U R2 F2 U F2 U2 D B L", "U2 B' U R2 U L2 B2 D' R2 U R2 B2 U' F' L2 R D B U2 B'", "B D' F L' D' B2 R L2 B' R2 F B2 L2 F2 L2 D2 R2 F R D R", "B2 R2 U' F2 D B2 R2 B2 F2 U R2 B L' D' R B D U' R D2", "F2 D2 L U2 L' D2 L B2 D2 R2 U2 D' B F' D R B' U2 L U' R'", "L R2 F D2 F' D2 B' D2 R2 B R2 F U L' F2 U' L' B' F2", "R' D2 F2 L2 B2 F2 L' D2 B2 R B2 R U' B D2 U L D L2 F2 D2", "U' F' D2 L' D2 L' B2 F2 R2 F2 R' B2 F2 R' B' U B2 L F' D2 U", "D B2 D L2 D' R2 D' U2 R2 F2 D L F' U' F D' L2 R' U L B", "F' D2 L B' R L B' U2 B2 D2 R2 F2 L' D2 L2 F2 L U", "D2 R2 U L2 F2 L2 B2 D F2 U2 R2 U' B' D L' R D' R' B R2 U2", "R' F U L2 U' B2 L2 R2 U B2 U2 B2 F D' U' F' L B F D", "R2 B' D' B R' F' D2 B D' R2 B D2 R2 F R2 L2 D2 L2 F'", "B' F2 D' F2 U' L2 U B2 U2 R D L D2 F L2 D' L2 U'", "D2 R2 U2 L B2 R' U2 B2 L' B2 D2 R D' F L U' B L2 F R U'", "L' D L R2 F D2 B' D2 U2 B2 F' L2 B' F' U' R' B' L' R D' R", "L' F2 L2 D2 F L2 U2 L2 D2 U2 B' U' F2 U L D B' R' F2", "B D L' U R' F' U R U2 D2 L B2 D2 B2 R2 B2 R B2 U' L2", "F2 L2 R2 U B2 D' R2 U B2 L2 R D2 R' U R B L F' D2 R'", "L2 D' U' F2 U L2 R2 D R2 D' R2 B' F R' D B2 F' R' D L' D'", "U' D' L F' U' B D F L2 F D2 B2 L2 U2 D2 B' D2 F U'", "L2 D L' R' F2 R D2 L' B2 U2 R F2 U2 R2 B D' F2 R' B L F'", "D R U L2 D L2 U' L2 D2 F2 U2 B2 U' L' F L U2 B' U2 R'", "U2 B' R F U' R2 B2 R2 B2 U F2 U' L2 B2 L' B D L' B' R2 D2", "F2 R' U2 F2 U B2 F2 L2 U B2 U L D2 L2 B R U R' F'"]
    
    var countdownTimer = Timer()
    var time = 15
    var invalidate = 0
    
    var secondsTimer = Timer()
    var secondsTime = 0
    
    var backgroundSecondTimer = Timer()
    var backgroundSeconds = 0.0
    
    var backgroundTenthTimer = Timer()
    var backgroundTenths = 0.0
    
    var backgroundHundrethTimer = Timer()
    var backgroundHundreths = 0.0
    
    var backgroundThousanthsTimer = Timer()
    var backgroundThousanths = 0.0
    
    var finalTime = 0.0
    var roundedFinalTime = 0.0
    
    var plusTwo = 0
    
    var colorChange = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Scramble.text = ThreescrambleArray.randomElement()
        
    }
    
    
    
        
    @objc func start() {
        
        time -= 1
        TimeLabel.text = String(time)
        if (time < 0 && time > -3) {
            TimeLabel.text = "+2"
            plusTwo = 1
            
        }
        else if (time <= -2) {
            TimeLabel.text = "DNF"
            countdownTimer.invalidate()
            plusTwo = 0
           
            invalidate = 0
            time = 15
            secondsTime = 0
            backgroundSecondTimer.invalidate()
            backgroundTenthTimer.invalidate()
            backgroundHundrethTimer.invalidate()
            backgroundThousanthsTimer.invalidate()
            secondsTimer.invalidate()
            Scramble.text = ThreescrambleArray.randomElement()
            backgroundSeconds = 0.0
            backgroundTenths = 0.0
            backgroundHundreths = 0.0
            backgroundThousanths = 0.0
            finalTime = 0.0
            roundedFinalTime = 0.0
            plusTwo = 0
            
        }
         
        
    }
    @IBAction func viewLongPress(_ gestureRecognizer: UILongPressGestureRecognizer) {
        
       
        
        if gestureRecognizer.state == .began {
            invalidate += 1
            colorChange = 0
            if (invalidate >= 3) {
                           
                           return
            }
            TimeLabel.textColor = .green
            
           
        }
        
        if gestureRecognizer.state == .ended {
            if (invalidate == 2) {
                
                cubingTimer()
                backgroundTimerSeconds()
                backgroundTimerTenthSeconds()
                backgroundTimerHundrethSeconds()
                backgroundTimerThousanthSeconds()
                countdownTimer.invalidate()
                TimeLabel.textColor = .white
                TimeLabel.text = "0"
               
                
                return
                      }
            else if (invalidate >= 3) {
                
                return 
            }
            TimeLabel.textColor = .white
            
            if (invalidate == 1) {
                TimeLabel.text = "15"
            countdownTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(TimerViewController.start), userInfo: nil, repeats: true)

            }
            
        }
        
        
        
        
    }
    
    @objc func firstDigit() {
        secondsTime += 1
        TimeLabel.text = String(secondsTime)
    }
    

    
    func cubingTimer() {
        
        secondsTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(TimerViewController.firstDigit), userInfo: nil, repeats: true)
        
    }
    
    @objc func backgroundFirstDigit() {
        
        backgroundSeconds += 1.0
        
            
        
        
    }
    
    
    func backgroundTimerSeconds() {
        
        backgroundSecondTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(TimerViewController.backgroundFirstDigit), userInfo: nil, repeats: true)

        
    }
    
    @objc func backgroundSecondDigit() {
        if (backgroundTenths <= 0.9) {
        backgroundTenths += 0.1
        }
        else {
            backgroundTenths = 0.0
        }
           
        
        
    }
    
    func backgroundTimerTenthSeconds() {
        
        backgroundTenthTimer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(TimerViewController.backgroundSecondDigit), userInfo: nil, repeats: true)
      

    
        
    }
    
    @objc func backgroundThirdDigit() {
        if (backgroundHundreths <= 0.09) {
        backgroundHundreths += 0.01
        }
        else {
            backgroundHundreths = 0.00
        }
    }
    
    func backgroundTimerHundrethSeconds(){
        
         backgroundHundrethTimer = Timer.scheduledTimer(timeInterval: 0.01, target: self, selector: #selector(TimerViewController.backgroundThirdDigit), userInfo: nil, repeats: true)
    }
    
    @objc func backgroundFourthDigit() {
        if (backgroundThousanths <= 0.009) {
        backgroundThousanths += 0.001
        }
        else {
            backgroundThousanths = 0.000
        }
    }
    
    func backgroundTimerThousanthSeconds() {
        
        backgroundThousanthsTimer = Timer.scheduledTimer(timeInterval: 0.001, target: self, selector: #selector(TimerViewController.backgroundFourthDigit), userInfo: nil, repeats: true)

    }
    
    
    
    override func touchesEnded(_ touchess: Set<UITouch>, with event: UIEvent?) {
        if let touchOne = touchess.first {
            _ = touchOne.location(in: self.view)
            if (colorChange == 1) {
            TimeLabel.textColor = .white
            }
            // do something with your currentPoint
        }
    }
   
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            _ = touch.location(in: self.view)
            if (invalidate == 0) {
                TimeLabel.textColor = .red
                colorChange = 1
            }
            if (invalidate >= 2) {

                       invalidate = 0
                       time = 15
                       secondsTime = 0
                       backgroundSecondTimer.invalidate()
                       backgroundTenthTimer.invalidate()
                       backgroundHundrethTimer.invalidate()
                       backgroundThousanthsTimer.invalidate()
                       finalTime = backgroundSeconds + backgroundTenths + backgroundHundreths + backgroundThousanths
                       if (plusTwo == 1) {
                           finalTime += 2.0
                       }
                       roundedFinalTime = Double(round(1000*finalTime)/1000)
                       if (plusTwo == 0) {
                       TimeLabel.text = String(roundedFinalTime)
                       }
                       else {
                           TimeLabel.text = String(roundedFinalTime) + "+"
                       }
                       secondsTimer.invalidate()
                       
                       Scramble.text = ThreescrambleArray.randomElement()
                       
                       
                       backgroundSeconds = 0.0
                       backgroundTenths = 0.0
                       backgroundHundreths = 0.0
                       backgroundThousanths = 0.0
                       finalTime = 0.0
                       roundedFinalTime = 0.0
                       plusTwo = 0
                      
                   }
            
            
        }
        
    }
   
    
    
}
    

   

    
    
   
        
        
        
    




