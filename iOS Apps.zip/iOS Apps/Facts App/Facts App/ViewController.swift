//
//  ViewController.swift
//  Facts App
//
//  Created by Mehul Chaudhari on 7/13/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

