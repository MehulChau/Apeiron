//
//  ViewController.swift
//  Cookie Clicker
//
//  Created by Mehul Chaudhari on 7/8/22.
//

import UIKit

class ViewController: UIViewController {
    
    var counter: Int = 0

    @IBOutlet weak var otherBtn: UIButton!
    @IBOutlet weak var btnReset: UIButton!
    @IBOutlet weak var btnClick: UIButton!
    @IBOutlet weak var Counter: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        Counter.text = "0"
        
    }

    @IBAction func otherbtnClick(_ sender: Any) {
        
        counter = counter + 8
        Counter.text = String (counter)
        
    }
    @IBAction func btnClick(_ sender: Any) {
        
        counter = counter + 1
        Counter.text = String (counter)
        
    }
    
    
    
    @IBAction func resetClick(_ sender: Any) {
        counter = 0
        Counter.text = String (counter)
    }
    
}

