//
//  ViewController.swift
//  Tippy
//
//  Created by Mehul Chaudhari on 7/12/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var billAmount: UITextField!
    @IBOutlet weak var tipAmount: UITextField!
    @IBOutlet weak var calculateTipBtn: UIButton!
    @IBOutlet weak var tipAmountLabel: UILabel!
    @IBOutlet weak var totalBillLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func calculateTip(_ sender: Any) {
        
        let billAmount:Double = Double(billAmount.text!)!
        let tipAmount:Double = (Double(tipAmount.text!)! / 100) * billAmount
        tipAmountLabel.text = String(format: "$%.02f", tipAmount)
        totalBillLabel.text = String(format: "$%.02f", billAmount + tipAmount)
        
    }
    
    @IBOutlet var hello: UIView!
}

