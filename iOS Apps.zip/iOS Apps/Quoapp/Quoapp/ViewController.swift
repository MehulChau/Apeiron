//
//  ViewController.swift
//  Quoapp
//
//  Created by Mehul Chaudhari on 7/16/22.
//

import Foundation
import UIKit
import UserNotifications

class ViewController: UIViewController {
    @IBOutlet weak var authorTxt: UILabel!
    @IBOutlet weak var quoteTxt: UITextView!
    @IBOutlet weak var refreshBtn: UIButton!
    
    struct Quote: Codable {
        var content: String
        var originator: Originator
    }
    
    struct Originator: Codable {
        var name: String
    }
    

    override func viewDidLoad() {
        loadQuoteNotification()
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        quoteTxt.isEditable = false
        setBackground()
    }
    
    
    func setBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = self.view.bounds
        gradientLayer.colors = [UIColor.systemBlue.cgColor, UIColor.systemPurple.cgColor]
        self.view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    @IBAction func refreshPresh(_ sender: Any) {
        loadQuote()
    }
   
    func createQuoteLabel(quote: String, author: String) {
        DispatchQueue.main.async {
            self.quoteTxt.text = quote
            self.authorTxt.text = author
        }
    }
    
    func getQoute(_ completion: @escaping(Quote?, Error?) -> Void) {
        // URL
        let url = URL(string: "https://quotes15.p.rapidapi.com/quotes/random/?language_code=en")
        
        guard url != nil else {
            print("Error creating url object")
            return
        }
        
        // URL Request
        var request = URLRequest(url: url!, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 10)
        
        // Specify the header
        let header = ["X-RapidAPI-Key": "3d72724e13mshd46b48870fef1afp188ca3jsn57de94570ee1",
                      "X-RapidAPI-Host": "quotes15.p.rapidapi.com"]
        
        request.allHTTPHeaderFields = header
        
        // Specify the body
        // Set the request type
        request.httpMethod = "GET"
        
        // Get the URLSession
        let session = URLSession.shared
        
        // Create the data task
        let dataTask = session.dataTask(with: request) { (data, response, error) in
            // Check for Errors
            if error == nil && data != nil {
                //Parse!
                let decoder = JSONDecoder()
                do {
                    let quote = try decoder.decode(Quote.self, from: data!)
                    completion(quote, nil)
                    self.createQuoteLabel(quote: quote.content, author: quote.originator.name)
                }
                catch {
                    print("Error in parsing")
                }
            }
        }
        // Fire off the data task
        dataTask.resume()
        
    } // End of getQoute func

    func loadQuote() {
        getQoute { (quote, error) in
            if let quote = quote {
                DispatchQueue.main.async {
                    self.quoteTxt.text = quote.content
                    self.authorTxt.text = quote.originator.name
                }
            } else if error != nil{
                print("Error in loading quote")
            }
        }
    }
    
    func loadQuoteNotification() {
            getQoute { (quote, error) in
                if let quote = quote {
                    var finalQuote = (quote.content + " - " + quote.originator.name)
                    let center = UNUserNotificationCenter.current()
                    
                    center.requestAuthorization(options: [.alert, .sound]) { (granted, error) in
                        //Here add in code for rejected notifs label to pop up
                    }
                    
                    let content = UNMutableNotificationContent()
                    content.title = "Your Daily Quotes"
                    content.body = finalQuote
                    
                    var dateComponenets = DateComponents()
                    let randomHour = Int.random(in: 1...23)
                    let randomMinute = Int.random(in: 0...59)
                    dateComponenets.hour = randomHour
                    dateComponenets.minute = randomMinute
                    
                    let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponenets, repeats: false)
                    
                    let uuidString = UUID().uuidString
                    let request = UNNotificationRequest(identifier: uuidString, content: content, trigger: trigger)
                    finalQuote = (quote.content + " - " + quote.originator.name)
                    
                    center.add(request) { (error) in
                        //Check the error parameter and handle any errors
                    }
                } else if error != nil {
                    print("Error in loading quote notification")
                }
            }
    }

} // End of Class


