//
//  ViewController.swift
//  Meme Generator
//
//  Created by Mehul Chaudhari on 7/14/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageLabel: UIImageView!
    @IBOutlet weak var btnClick: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        imageLabel.image = UIImage (named: "youtube")
    }

    @IBAction func imageBtn(_ sender: Any) {
        
        getMeme()
        
    }
    
    func getMeme() {
        
        var imageName = ""
        let number = Int.random(in: 1...3)
        
        switch number {
            
        case 1: imageName = "youtube"
        case 2: imageName = "politicians"
        case 3: imageName = "mike"
        default: imageName = ""
        }
        
        imageLabel.image = UIImage (named: imageName)
    }
    
}

